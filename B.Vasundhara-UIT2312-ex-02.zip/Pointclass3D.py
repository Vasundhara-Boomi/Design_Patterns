#PointClass in 3-Dimensional

import math
class PointClass3D():
    def __init__(self,c1,c2):                 #Initialization of x and y
        self.c1=c1
        self.c2=c2
    def reset(self):                        #Values resetted to zero
       self.c1=0,0,0
       self.c2=0,0,0
       print("Reset:")
       print(self.c1,self.c2)
    def distance(self):                     #Calculating the distance in three dimensional form
        A=(self.c1).split(',')
        B=(self.c2).split(',')
        x1,y1,z1=int(A[0]),int(A[1]),int(A[2])
        x2,y2,z2=int(B[0]),int(B[1]),int(B[2])
        d1=x2-x1
        d2=y2-y1
        d3=z2-z1
        dist=d1**2+d2**2+d3**2
        distance=math.sqrt(dist)
        print("Distance:")
        print(distance)
    def conversion(self):                   #converting 3-dimensional to 2-dimensional
        A=(self.c1).split(',')
        B=(self.c2).split(',')
        x1,y1,z1=int(A[0]),int(A[1]),int(A[2])
        x2,y2,z2=int(B[0]),int(B[1]),int(B[2])
        p,q,r,s=round((x1/z1),2),round((x2/z2),2),round((y1/z1),2),round((y2/z2),2)
        print("Conversion 3D t0 2D")
        print((p,r),(q,s))
c1=input("enter coordinate1 in 3D:")                
c2=input("enter coordinate2 in 3D:")
ans=PointClass3D(c1,c2)                       #Creating object for the class
Q1=ans.distance()                           #calling the distance function
Q2=ans.conversion()                         #calling the conversion function
Q2=ans.reset()                              #Calling the reset function