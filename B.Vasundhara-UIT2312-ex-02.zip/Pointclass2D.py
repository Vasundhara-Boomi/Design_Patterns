#PointClass in 2-Dimensional

import math
class PointClass2D():
    def __init__(self,c1,c2):         #Initialization of x and y
        self.c1=c1
        self.c2=c2
    def reset(self):                #Values resetted to zero
       self.c1=0,0
       self.c2=0,0
       print("Reset:")
       print(self.c1,self.c2)
    def distance(self):             #Calculating the distance in two dimensional form
        A=(self.c1).split(',')
        B=(self.c2).split(',')
        x1,y1=int(A[0]),int(A[1])
        x2,y2=int(B[0]),int(B[1])
        d1=x2-x1
        d2=y2-y1
        dist=d1**2+d2**2
        distance=math.sqrt(dist)
        print("Distance:")
        print(distance)
    def conversion(self): 
        A=(self.c1).split(',')
        B=(self.c2).split(',')
        x1,y1,z1=int(A[0]),int(A[1]),0
        x2,y2,z2=int(B[0]),int(B[1]),0                            #Converting 2-Dimensional to 3-Dimensional
        print("Conversion 2D to 3D:")
        print((x1,y1,z1),(x2,y2,z2))

c1=input("enter coordinate1 in 2D:")
c2=input("enter coordinate2 in 2D:")
ans=PointClass2D(c1,c2)               #Creating object for the class
Q1=ans.distance()                   #calling the distance function
Q2=ans.conversion()                 #Calling the conversion function
Q3=ans.reset()                      #calling the reset function