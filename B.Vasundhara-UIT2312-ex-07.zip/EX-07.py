import re
import random

class credentitals:

    def username(self):
        USERNAME = str(input("ENTER YOUR USERNAME: "))
        x = re.search("[a-zA-Z]", USERNAME)
        y = re.findall("[0-9]", USERNAME)
        if x and y:
            # print(x.string)
            print("VALID USERNAME")
        else:
            print("INVALID USERNAME, USERNAME MUST CONTAIN ANY OF THE ALPHABETS AND NUMBERS")
            quit()

    def password(self):
        PASSWORD = input("ENTER YOUR PASSWORD : ")
        x = re.search("[a-zA-Z]", PASSWORD)
        y = re.findall("[0-9]", PASSWORD)
        z = re.findall("[@#!*&^%$]", PASSWORD)
        if x and y and z:
            print("VALID PASSWORD")
        else:
            print("INVALID INPUT, PASSWORS MUST CONTAIN ANY OF THE ALPHABETS AND NUMBERS AND @ or # SYMBOL")
            quit()

    def mobile_number(self):
        MOBILE_NUMBER = str(input("ENTER YOUR MOBILE NUMBER : "))
        y = re.findall("\d", MOBILE_NUMBER)
        if y and len(MOBILE_NUMBER) == 10:
            print("VALID MOBILE NUMBER")
        else:
            print("INVALID MOBILE NUMBER")
            quit()

    def email_id(self):
        c = r"^\S+@\S+\.\S+$"
        EMAIL_ID = str(input("ENTER YOUR EMAIL ID : "))
        if re.fullmatch(c, EMAIL_ID):
            print("VALID EMAIL ID")
        else:
            print("INVALID EMAIL ID")
            quit()

    def captcha(self):
        words = ['tree', 'sun', 'ball', 'moon', 'earth', 'grass', 'world']
        CAPTCHA = random.choice(words)
        print(CAPTCHA)
        ENTER_CAPTCHA = input("ENTER THE ABOVE CAPTCHA : ")
        if ENTER_CAPTCHA in words:
            print("VALID CAPTCHA")
            print("---------------------------------------LOGIN SUCCESSFUL------------------------------------------")
        else:
            print("INVALID CAPTCHA")

o = credentitals()
o.username()
o.password()
o.mobile_number()
o.email_id()
o.captcha()