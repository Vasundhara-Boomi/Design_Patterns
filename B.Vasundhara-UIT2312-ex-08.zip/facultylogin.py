#F1 - falcuty json file
import json
class Faculty:
#------------------------------------login---------------------------------------------------  
  def Login(n1,p1):
    
    f2 = open('F1.json','r')
    ab = json.loads(f2.read())
    f2.close()
    try:
      for i in ab['d']:
       if i['name'] == n1 and i['pass']==p1:
        print("you are logged in!!!!!!!!!")
        print('\033[1m'+"WELCOME BACK %s"%n1+'\033[0m')
        f4 = open("F2.json",'r')
        ans = json.loads(f4.read())
        print("\n")
        print('\033[1m'+'********************************* CAT Marks of IT-B **************************** '+'\033[0m')
        for i in ans['d']:
          print(f"{i['name']} \n  - maths: {i['maths']} \n  - Design patterns : {i['depat']} \n  - Database: {i['data']} ")
        print('\033[1m'+'******************************************************************************** '+'\033[0m')
    except:
        print("incorrect username!!!!! better sign up!!!!!!")
  def Signin():
    n1 = input("enter your username:")
    p1 = input("enter your password:")
    p2 = input("re-enter the password:")
    j = input("Enter your join date:")
    if p1 == p2:
      f2 = open('F1.json','r')
      ab = json.loads(f2.read())
      a=ab['d']
      a.append({'name':n1,'pass':p1,'join':j})
      f2.close()
      f2 = open('F1.json','w')
      ab = json.dump({"d":a},f2)
      print("Updated!!!! try loging in now!!!!")
  
  def Search(n1,p1):
    f2 = open('F1.json','r')
    ab = json.loads(f2.read())
    f2.close()
    try:
      for i in ab['d']:
       if i['name'] == n1 and i['pass']==p1:
        print("you are logged in!!!!!!!!!")
        print('\033[1m'+"WELCOME BACK %s"%n1+'\033[0m')
        a = input("enter the name of the student:")
        f2 = open('F2.json','r')
        ab = json.loads(f2.read())
        f2.close()
        for i in ab['d']:
          if i['name'] == a:
            print("Student Found!!!!!!!!!")
            print('\033[1m'+'******************************************************************************** '+'\033[0m')
            print(f"{a} \n   Maths: {i['maths']} \n   Design patterns: {i['depat']} \n   Database: {i['data']} \n   Attendance: {i['attend']} \n   Average: {i['avg']} ")
            print('\033[1m'+'******************************************************************************** '+'\033[0m')
    except:
        print("incorrect username!!!!! better sign up!!!!!!")