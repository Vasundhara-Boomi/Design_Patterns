from StudentLogin import Student
from facultylogin import Faculty

#-------------------WELCOME PAGE-------------------------------------
print('\033[1m'+'WELCOME  TO THE SITE '.center(20)+'\033[0m')
print("1.Faculty \n2.Student ")
a= int(input("your choice(1/2):"))
if a==1:
    cnt = 'y'
    n1 = input("Enter your username:")
    p1 = input("Enter your password:")
    while cnt!='n':
     print("1.View \n2.Search ")
     b = int(input("your choice(1/2):"))
     if b==1:  
       Faculty.Login(n1,p1)
     else:
        Faculty.Search(n1,p1)
     cnt = input("Do you want to continue?(y/n):")
else:
    n1 = input("Enter your username:")
    p1 = input("Enter your password:")
    Student.Login(n1,p1)