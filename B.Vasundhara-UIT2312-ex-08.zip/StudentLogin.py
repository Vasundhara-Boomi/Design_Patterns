#F1 - Student json file
import json
class Student():
    
 #------------------------ LOGIN PAGE-----------------------------------
  def Login(n1,p1):

    f2 = open('F2.json','r')
    ab = json.loads(f2.read())
    try:
      for i in ab['d']:
       if i['name'] == n1 and i['pass']==p1:
         print("you are logged in!!!!!!!!!")
         print('\033[1m'+"WELCOME BACK %s"%n1+'\033[0m')
         print('\033[1m'+'********************************* Your CAT Marks ******************************* '+'\033[0m')
         print(f"{n1} \n   Maths: {i['maths']} \n   Design patterns: {i['depat']} \n   Database: {i['data']} \n   Attendance: {i['attend']} \n   Average: {i['avg']} ")
         print('\033[1m'+'******************************************************************************** '+'\033[0m')
            
    except:
        print("incorrect username!!!!! better sign up!!!!!!")