class book:
    def __init__(self,title=None,isbn=None, dds=None):
        self.title=title
        self.isbn=isbn
        self.dds=dds 
class magazine:
    def __init__(self,title=None,upc=None,issue=None,volume=None):
        self.title=title
        self.upc=upc
        self.issue=issue
        self.volume=volume  
class cd:
    def __init__(self,title=None, upc=None, author=None):
        self.title=title 
        self.upc=upc 
        self.author=author  

class library_catalog:
    def __init__(self):
         self.list=[{}]*6
    
    def add_to_library(self, item):
        #first 4 rows are for books, 5th row is for magazines & 6th row is for dvd/cds 
        if isinstance(item,book):
            row=item.dds%4 
            shelf=item.dds%10
        elif isinstance(item,magazine):
            row=4
            shelf=item.upc%10
        else:
            row=5
            shelf=item.author.split()[1].lower()
        
        if shelf not in self.list[row]:
            self.list[row][shelf]=[item]
        else:
            self.list[row][shelf].append(item)
    
    def search(self, itemtype,dds=None, upc=None):
        if (itemtype.lower()=="book"):
            try:
                for i in self.list[dds%4][dds%10]:
                    if i.dds==dds:
                        print("the book is found in row no: %s, shelf no : %s"%(1+dds%4,1+dds%10))
                        break 
                else:
                    print("The book is currently not available")
            except:
                print("The book is currently not available")
        elif (itemtype.lower()=="magazine"):
            try:
                for i in self.list[4][upc%10]:
                    if (i.upc==upc):
                        print("the magazine is found in row: 5, shelf: %s"%(1+upc%10))
                        break 
                else:
                    print("The magazine is currently not available")
            except:
                print("The magazine is not currently available")
        else:
            author=input("Enter the full name of the author: ")
            lname=author.split()[1].lower()
            if lname in self.list[5]:
                for i in self.list[5][lname]:
                    if i.upc==upc:
                        print("The cd/dvd is found in row 6")
                        break 
                else:
                    print("The cd/dvd is currently not available")
            else:
                print("The cd/dvd is currently not available")

a=library_catalog()

p="y"
while(p=="y"):
    print("Menu")
    print("1. Add an item\n2.Search for an item")
    ch=int(input("Enter your choice: "))
    if(ch==1):
        t=input("Enter the type of item(book/magazine/cd/dvd): ")
        if (t.lower()=="book"):
            title=input("Enter the title of the book: ")
            isbn=int(input("Enter the isbn number: "))
            dds=int(input("Enter the dds number: "))
            a.add_to_library(book(title,isbn,dds))
            print("Book added!")
        elif t.lower()=="magazine":
            title=input("Enter the title of the magazine: ")
            upc=int(input("Enter the upc number: "))
            issue=int(input("Enter the issue number: "))
            vol=int(input("Enter the volume number: "))
            a.add_to_library(magazine(title,upc,issue,vol))
        elif t.lower()=="cd" or t.lower()=="dvd":
            title=input("Enter the title of the cd/dvd: ")
            upc=int(input("Enter the upc number: "))
            author=input("Enter the name of the author(first name + last name): ")
            a.add_to_library(cd(title,upc,author))
        else:
            print("Invalid type")
    elif ch==2:
        t=input("Enter the item you're looking for: ")
        if(t.lower()=="book"):
            dds=int(input("Enter the dds number: "))
            a.search(t,dds)
        elif t.lower()=="magazine":
            upc=int(input("Enter the upc number: "))
            a.search(t,None,upc)
        elif t.lower()=="cd" or t.lower()=="dvd":
            upc=int(input("Enter the upc number: "))
            a.search(t,None,upc)
        else:
            print("Invalid type")
    p=input("Do you want to continue(y/n): ")