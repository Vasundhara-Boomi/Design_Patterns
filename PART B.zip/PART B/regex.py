import re

def check(string,ch):
	if ch==1:
		identifier = '^[A-Za-z_][A-Za-z0-9_]*'
		if(re.search(identifier, string)):
			print("Valid Identifier")
		else:
			print("Invalid Identifier")

	elif ch==2:
		reg = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{6,20}$"
		if(re.search(reg, string)):
			print("Valid Password")
		else:
			print("Invalid Password")

	elif ch==3:
		digit = '^[0-9]+$'
		if(re.search(digit, string)):
			print("String is numeric")
		else:
			print("String isn't numeric")

	elif ch==4:
		hexa='[0-9a-fA-F]'
		if(re.search(hexa, string)):
			print("String is hexadecimal")
		else:
			print("String isn't hexadecimal")
            
print( "   CHOICES \n"
      "1. Identifier \n"
      "2. Password \n"
      "3. Numeric  \n"
      "4. Hexadecimal  \n")
