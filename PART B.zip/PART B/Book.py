from BookF import BookD
import json
class Book:
    
    def __init__(self):
        with open("book.json","r") as b:
            self.books=json.load(b)

    def new_book(self,title,isbn,webstore,price):
        book=BookD(title,isbn,webstore,price)
        #To get the serial no for the book
        k=self.books.keys()
        m=int(max(k))+1
        self.books[str(m)]=[title,isbn,webstore,price]
        with open("book.json","w") as b:
            json.dump(self.books,b)
        print("Sucessfully added!")

    def modify_price(self,title,webstore):
        for book in self.books:
            #title and webstore together uniquely identifies the product
            if self.books[book][0].lower()==title.lower():
                if self.books[book][2].lower()==webstore.lower():
                   p=int(input("Enter the new price: "))
                   self.books[book][3]=p
                   #dumping into the json file
                   with open("book.json","w") as b:
                    json.dump(self.books,b)
                    print("Sucessfully updated!")
                   break
        else:
            print("Product not found")
        
    def display(self):
        #Using string formatting to display the details
        gap=" "*3
        heading=f"{'Sno':3s}{gap}{'Title':23s}{gap}{'ISBN':5s}{gap}{'Webstore':10s}{gap}{'Price':6s}"
        print('='*60)
        print(heading)
        print("-"*60)
        for book in self.books:
            rec=f"{book:3s}{gap}{self.books[book][0]:23s}{gap}{self.books[book][1]:5d}{gap}{self.books[book][2]:10s}{gap}{self.books[book][3]:6d}"
            print(rec)
 
b=Book()
print("    CHOICES \n"
      "1. Add new book \n"
      "2. Modify Price \n"
      "3. Display  \n")
ch=int(input("Enter your choice: "))
if ch==1:
    name=input("Enter the title of the Book: ")
    isbn=int(input("Enter the isbn: "))
    web=input("Enter the webstore: ")
    price=int(input("Enter the price: "))
    b.new_book(name,isbn,web,price)
if ch==2:
    name=input("Enter the title of the Book: ")
    web=input("Enter the webstore: ")
    b.modify_price(name,web)
if ch==3:
    b.display()
    


#b.modify_price("python programming","amazon")

