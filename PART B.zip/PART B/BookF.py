class BookD:
    def __init__(self,title,isbn,webstore,price):
        self.title=title
        self.isbn=isbn
        self.webstore=webstore
        self.price=price